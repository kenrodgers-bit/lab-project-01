DROP TABLE IF EXISTS password_reset_tokens;
